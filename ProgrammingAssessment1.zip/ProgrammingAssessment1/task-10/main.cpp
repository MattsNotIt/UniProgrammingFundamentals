#include <iostream>

#include "structures.h"
#include "methods.h"

int main(int argc, char* argv[])
{
    //Insert your code to complete challenge 10
    return 0;
}