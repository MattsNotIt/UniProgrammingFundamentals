#include <iostream>

int main(int argc, char* argv[])
{
    //Insert your code to complete challenge 8
    return 0;
}