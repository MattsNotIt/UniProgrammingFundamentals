#include <iostream>

int main(int argc, char* argv[])
{
    using namespace std;

    cout << "                  |                  \n";
    cout << "                 /|\\                \n";
    cout << "                / | \\               \n";
    cout << "               /  |  \\              \n";
    cout << "              / --|-- \\             \n";
    cout << "             /    |    \\            \n";
    cout << "            /-----|-----\\           \n";
    cout << "     |----\\       |       /----|    \n";
    cout << "      \\- - --------------- - -/     \n";
    cout << "       \\- -- - - - - - - -- -/      \n";
    cout << " /\\  /\\ \\/\\  /\\  /\\  /\\  /\\ //\\  /\\ \n";
    cout << "/  \\/  \\/  \\/  \\/  \\/  \\/  \\/  \\/  \\";

    return 0;
}
