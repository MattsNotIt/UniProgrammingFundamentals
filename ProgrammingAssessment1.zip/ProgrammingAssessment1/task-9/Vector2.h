#pragma once

class Vector2
{
    //Here you should fill out the class according
    //to what is requested by challenge #9.   
};