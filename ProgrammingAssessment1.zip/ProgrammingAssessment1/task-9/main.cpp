#include <iostream>
#include "Vector2.h"

int main(int argc, char* argv[])
{
    //Please build your interactive calculator, using the
    //Vector2 class, here.
    return 0;
}